package com.capgemini.laps.bean;

import java.util.Date;

public class LoanApplicationBean {

	
	private int applicationId;
	private Date applicationDate;
	private String loanProgram;
	private long amountOfLoan;
	private String addressOfProperty;
	private long annualFamilyIncome;
	private String documentProofsAvailable;
	private String guaranteeCover;
	private int marketValueOfGuaranteeCover;
	private String status;
	private Date dateOfInterview;
	public int getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(int applicationId) {
		this.applicationId = applicationId;
	}
	public Date getApplicationDate() {
		return applicationDate;
	}
	public void setApplicationDate(Date applicationDate) {
		this.applicationDate = applicationDate;
	}
	public String getLoanProgram() {
		return loanProgram;
	}
	public void setLoanProgram(String loanProgram) {
		this.loanProgram = loanProgram;
	}
	public long getAmountOfLoan() {
		return amountOfLoan;
	}
	public void setAmountOfLoan(long amountOfLoan) {
		this.amountOfLoan = amountOfLoan;
	}
	public String getAddressOfProperty() {
		return addressOfProperty;
	}
	public void setAddressOfProperty(String addressOfProperty) {
		this.addressOfProperty = addressOfProperty;
	}
	public long getAnnualFamilyIncome() {
		return annualFamilyIncome;
	}
	public void setAnnualFamilyIncome(long annualFamilyIncome) {
		this.annualFamilyIncome = annualFamilyIncome;
	}
	public String getDocumentProofsAvailable() {
		return documentProofsAvailable;
	}
	public void setDocumentProofsAvailable(String documentProofsAvailable) {
		this.documentProofsAvailable = documentProofsAvailable;
	}
	public String getGuaranteeCover() {
		return guaranteeCover;
	}
	public void setGuaranteeCover(String guaranteeCover) {
		this.guaranteeCover = guaranteeCover;
	}
	public int getMarketValueOfGuaranteeCover() {
		return marketValueOfGuaranteeCover;
	}
	public void setMarketValueOfGuaranteeCover(int marketValueOfGuaranteeCover) {
		this.marketValueOfGuaranteeCover = marketValueOfGuaranteeCover;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getDateOfInterview() {
		return dateOfInterview;
	}
	public void setDateOfInterview(Date dateOfInterview) {
		this.dateOfInterview = dateOfInterview;
	}
	
	
	public LoanApplicationBean() {
		super();

	}
	public LoanApplicationBean(String loanProgram, long amountOfLoan,
			String addressOfProperty, long annualFamilyIncome,
			String documentProofsAvailable, String guaranteeCover,
			int marketValueOfGuaranteeCover) {
		super();
		this.loanProgram = loanProgram;
		this.amountOfLoan = amountOfLoan;
		this.addressOfProperty = addressOfProperty;
		this.annualFamilyIncome = annualFamilyIncome;
		this.documentProofsAvailable = documentProofsAvailable;
		this.guaranteeCover = guaranteeCover;
		this.marketValueOfGuaranteeCover = marketValueOfGuaranteeCover;
	}
	@Override
	public String toString() {
		return "LoanApplicationBean [applicationId=" + applicationId
				+ ", applicationDate=" + applicationDate + ", loanProgram="
				+ loanProgram + ", amountOfLoan=" + amountOfLoan
				+ ", addressOfProperty=" + addressOfProperty
				+ ", annualFamilyIncome=" + annualFamilyIncome
				+ ", documentProofsAvailable=" + documentProofsAvailable
				+ ", guaranteeCover=" + guaranteeCover
				+ ", marketValueOfGuaranteeCover="
				+ marketValueOfGuaranteeCover + ", status=" + status
				+ ", dateOfInterview=" + dateOfInterview + "]";
	}
	
	
	
	
	
}
