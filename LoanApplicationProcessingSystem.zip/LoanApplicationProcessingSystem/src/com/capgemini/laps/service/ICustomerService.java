package com.capgemini.laps.service;

import com.capgemini.laps.bean.CustomerDetailsBean;
import com.capgemini.laps.bean.LoanApplicationBean;
import com.capgemini.laps.exception.LoanException;

public interface ICustomerService {

	public abstract int addApplicationDetails(LoanApplicationBean loanApplicationBean) throws LoanException;

	public abstract boolean addCustomerDetails(CustomerDetailsBean customerBean)throws LoanException;

	public abstract String getApplicationStatus(int appId) throws LoanException;

	

	

	public abstract boolean isValidApplicationId(int appId);

	

	

	public abstract boolean isValidLoanProgram(String loanProgram);

	public abstract boolean isValidAmountOfLoan(long amountOfLoan);

	public abstract boolean isValidAddressOfProperty(String addressOfProperty);

	public abstract boolean isValidAnnualFamilyIncome(long annualFamilyIncome);

	public abstract boolean isValidDocumentProofsAvailable(String documentProofsAvailable);

	public abstract boolean isValidGuaranteeCover(String guaranteeCover);

	public abstract boolean isValidMarketValueOfGuaranteeCover(int marketValueOfGuaranteeCover);

	
	
	
	public abstract boolean isValidApplicantName(String applicantName);

	public abstract boolean isValidDateOfBirth(String dateOfBirth);

	public abstract boolean isValidMaritalStatus(String maritalStatus);

	public abstract boolean isValidPhoneNumber(long phoneNumber);

	public abstract boolean isValidMobileNumber(long mobileNumber, long phoneNumber);

	public abstract boolean isValidCountOfDependents(int countOfDependents);

	public abstract boolean isValidEmailId(String emailId);

}
