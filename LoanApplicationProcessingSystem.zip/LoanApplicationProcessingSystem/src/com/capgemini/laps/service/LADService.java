package com.capgemini.laps.service;

import java.util.List;

import com.capgemini.laps.bean.ApprovedLoansBean;
import com.capgemini.laps.bean.LoanApplicationBean;
import com.capgemini.laps.dao.ILADDAO;
import com.capgemini.laps.dao.LADDAO;
import com.capgemini.laps.exception.LoanException;

public class LADService implements ILADService {

	ILADDAO ladDAO =null;
	
	public LADService() {

	ladDAO = new LADDAO();
	}

	

	@Override
	public List<LoanApplicationBean> viewApplications(String loanProgram) throws LoanException {
      
		List<LoanApplicationBean> loanApplicationList = ladDAO.viewApplications(loanProgram);
		return loanApplicationList;
	}



	@Override
	public boolean isValidApplicationId(int appId) {
		return (appId >0);	}






	@Override
	public boolean isValidApplicationStatus(String status,String currentStatus) {
		if("Applied".equals(currentStatus))
		return ("Accepted".equals(status) || "Rejected".equals(status));
		else if("Accepted".equals(currentStatus))
			return("Approved".equals(status) || "Rejected".equals(status));
		else
			return false;
		
	}



	@Override
	public String modifyApplicationStatus(int appId, String status) throws LoanException {
		return ladDAO.modifyApplicationStatus(appId,status);
	}



	@Override
	public String getCurrentStatus(int appId) {
		return ladDAO.getCurrentStatus(appId);
	}



	@Override
	public String getCustomerName(int appId) {
		return ladDAO.getCustomerName(appId);
	}



	@Override
	public long getAmountOfLoanGranted(int appId) {
		return ladDAO.getAmountOfLoanGranted(appId);
	}



	@Override
	public int getYearsTimePeriod(int appId) {
		return ladDAO.getYearsTimePeriod(appId);
	}



	@Override
	public float getRateOfInterest(int appId) {
		return ladDAO.getRateOfInterest(appId);
	}



	@Override
	public boolean addApprovedLoansDetails(ApprovedLoansBean approvedLoansBean) {
		return ladDAO.addApprovedLoansDetails(approvedLoansBean);
	}



	@Override
	public boolean isValidReply(String reply) {

		return ("YES".equals(reply.toUpperCase()) || "NO".equals(reply.toUpperCase()));
	}

}
