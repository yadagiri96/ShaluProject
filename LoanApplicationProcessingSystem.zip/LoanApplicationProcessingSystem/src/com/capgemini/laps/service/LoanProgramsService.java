package com.capgemini.laps.service;

import java.util.List;


import com.capgemini.laps.bean.LoanProgramsBean;
import com.capgemini.laps.dao.ILoanProgramsDAO;
import com.capgemini.laps.dao.LoanProgramsDAO;
import com.capgemini.laps.exception.LoanException;

public class LoanProgramsService implements ILoanProgramsService {

	ILoanProgramsDAO loanDAO = null;
	
	public LoanProgramsService() {
	
		loanDAO= new LoanProgramsDAO();
	}
	@Override
	public List<LoanProgramsBean> displayAll() throws LoanException{
        
		//loanDAO= new LoanProgramsDAO();
		List<LoanProgramsBean> loanProgramsList = loanDAO.displayAll();
		
		
		return loanProgramsList;
	}
	@Override
	public String login(String logid, String pwd) throws LoanException {

		
		return loanDAO.login(logid,pwd);
	}
	
	
	

}
