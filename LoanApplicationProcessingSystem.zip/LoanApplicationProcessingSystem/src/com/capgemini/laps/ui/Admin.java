package com.capgemini.laps.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.laps.bean.ApprovedLoansBean;
import com.capgemini.laps.bean.LoanApplicationBean;
import com.capgemini.laps.bean.LoanProgramsBean;
import com.capgemini.laps.exception.LoanException;
import com.capgemini.laps.service.AdminService;
import com.capgemini.laps.service.IAdminService;


public class Admin {
	
	static IAdminService adminService=null;
	static Scanner scanner = new Scanner(System.in);
	static LoanApplicationBean loanApplicationBean=null;
	static  LoanProgramsBean loanProgramsBean = null;
	static BufferedReader buffer = new BufferedReader(new InputStreamReader(System.in));
    static ApprovedLoansBean approvedLoansBean =null;
    static Logger logger = Logger.getRootLogger();
	static void callAdminPage() throws IOException {

		System.out.println();
		System.out.println("----------------------------------------------------------------------------");
		System.out.println();
		
		System.out.println("1) Add Loan Program.");
		System.out.println("2) Delete Loan Program. ");
		System.out.println("3) Available Loan Applications on the basis of Application Status (Applied / Accepted / Rejected / Approved)");
		System.out.println("4) Available Loan Programs Are :  ");
		System.out.println("5) Display Approved Loans : ");
		System.out.println("6) LogOut... !! ");
		System.out.println("7) Exit .. !! ");
		System.out.println();
		System.out.println("-----------------------------------------------------------------------------");
		System.out.println();
		System.out.println("Please Choose An Option Given Above.  ");
		try{
		int adminOption = scanner.nextInt();
		
		
		switch(adminOption){
		
		
		case 1:
			String reply = null;
			do{
			while(loanProgramsBean == null){
			loanProgramsBean = populateLoanProgramsBean();
			}
			try{
			adminService = new AdminService();
			boolean added = adminService.addLoanPrograms(loanProgramsBean);
			if(added == true )
				System.out.println("Loan Program Added Successfully ...!! ");
			else{
				System.out.println();
				System.out.println();
				System.err.println("Loan Program Addition Opertion Failed ...!! ");
			}
			}catch (Exception e){
				System.err.println("Loan Application ERROR : "+ e.getMessage());
			}
			System.out.println();
			loanProgramsBean = null;
			System.out.println("Do You Want To Continue Adding.. ?? Yes / No ");
			reply = buffer.readLine();
			while(true){
				if(adminService.isValidReply(reply))
					break;
				else{
					System.out.println("Reply will be Yes / No Only ... !!");
					reply = buffer.readLine();
				}
			}
			}while("YES".equals(reply.toUpperCase()));
			callAdminPage();
			break;
			
			
		case 2:
			do{
				System.out.println();
				System.out.println("Loan Programs Provided By Home Finance Provider Are ----- ");
				System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
				System.out.println();
				User.viewPrograms();
				System.out.println();
				System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
				
			System.out.println();
			System.out.println("Enter the Loan Program's Name which you want to DELETE : ");
			String programName = buffer.readLine();
			try{
			adminService = new AdminService();
			boolean deleted = adminService.deleteLoanProgram(programName);
			if(deleted == true )
				System.out.println("Loan Program Deleted Successfully ...!! ");
			else
				System.err.println("Loan Program Deletion Opertion Failed ...!! ");
			}catch (Exception e){
				System.err.println("Loan Application ERROR : "+ e.getMessage());
			}
			System.out.println();
			System.out.println("Do You Want To Continue Deleting.. ?? Yes / No ");
			reply = buffer.readLine();
			while(true){
				if(adminService.isValidReply(reply))
					break;
				else{
					System.out.println("Reply will be Yes / No Only ... !!");
					reply = buffer.readLine();
				}
			}
			}while("YES".equals(reply.toUpperCase()));
			callAdminPage();
			break;
			
			
		case 3:
			do{
			System.out.println();
			System.out.println();
			System.out.println("Enter the Application Status : ");
			System.out.println("1. Applied \n 2. Accepted \n 3. Rejected \n 4. Approved \n Please Choose From Above Options... !!");
			int option=0;
			String applicationStatus = null;
			try{
				option = scanner.nextInt();
				switch(option){
				case 1:
					applicationStatus = "Applied";
					break;
				case 2:
					applicationStatus = "Accepted";
					break;
				case 3:
					applicationStatus = "Rejected";
					break;
				case 4:
					applicationStatus = "Approved";
					break;
					default:
						System.out.println("Enter Numeric Value Between [1-4]... !!");
						break;
				}
			}catch (InputMismatchException e) {
				scanner.nextLine();
				System.err.println("Please enter the numeric value, try again");
			}
		adminService = new AdminService();
		while (true){
			
			if(adminService.isValidApplicationStatus(applicationStatus)){
				System.out.println("Valid");
				break;
			}else {
				System.err.println(" Application Status Could Be Chosen Only as (Applied / Accepted / Rejected / Approved)... !! ");

				System.out.println();
				System.out.println("Enter the Application Status : ");
				System.out.println("1. Applied \n 2. Accepted \n 3. Rejected \n 4. Approved \n Please Choose From Above Options... !!");
				
				try{
					option = scanner.nextInt();
					switch(option){
					case 1:
						applicationStatus = "Applied";
						break;
					case 2:
						applicationStatus = "Accepted";
						break;
					case 3:
						applicationStatus = "Rejected";
						break;
					case 4:
						applicationStatus = "Approved";
						break;
						default:
							System.out.println("Enter Numeric Value Between [1-4]... !!");
							break;
					}
				}catch (InputMismatchException e) {
					scanner.nextLine();
					System.err.println("Please enter the numeric value, try again");
				}
			}
			
		}
			
			adminService = new AdminService();
			
			List<LoanApplicationBean> loanApplicationList = new ArrayList<LoanApplicationBean>();
			try {
				loanApplicationList = adminService.viewApplications(applicationStatus);
			
			if (loanApplicationList != null) {
				System.out.println();
				System.out.println("------------------------------------");
				System.out.println("Available Loan Applications Are : ");
				System.out.println();
				System.out.println("*******************************************************************************************************************************");
				System.out.println("*******************************************************************************************************************************");
				System.out.println();
				Iterator<LoanApplicationBean> i = loanApplicationList.iterator();
				while (i.hasNext()) {
					System.out.println(i.next());
				}
				System.out.println();
				System.out.println("*******************************************************************************************************************************");
				System.out.println("*******************************************************************************************************************************");
			} else {
				System.out.println();
				System.err.println("No loan Application available of this Status...!!");
			}
			}catch (LoanException e) {

				System.out.println("Error  :" + e.getMessage());
			}
			System.out.println("Do You Want To Continue Viewing Loan Applications On The Basis Of Application Status ?? Yes / No ");
			reply = buffer.readLine();
			while(true){
				if(adminService.isValidReply(reply))
					break;
				else{
					System.out.println("Reply will be Yes / No Only ... !!");
					reply = buffer.readLine();
				}
			}
			}while("YES".equals(reply.toUpperCase()));

			System.out.println();
			callAdminPage();
			break;
			
			
		case 4:
			System.out.println();
			System.out.println("Loan Programs Provided By Home Finance Provider Are ----- ");
			System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
			System.out.println();
			User.viewPrograms();
			System.out.println();
			System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
			System.out.println();
			callAdminPage();
			break;
			
		case 5:
			 adminService = new AdminService();
				try {
					List<ApprovedLoansBean> approvedLoansList = new LinkedList<ApprovedLoansBean>();
					approvedLoansList = adminService.displayAllApprovedLoans();

					if (approvedLoansList != null) {
						Iterator<ApprovedLoansBean> i = approvedLoansList.iterator();
						while (i.hasNext()) {
							System.out.println(i.next());
						}
					} else {
						System.out.println("No Approved Loans available.");
					}
				}

				catch (LoanException e) {

						System.out.println("Error  :" + e.getMessage());
					}
				callAdminPage();
					break;
			
		case 6:
			
			
			System.out.println("You Logged Out Successfully... !! ");
			System.out.println();
			User.logout();
			
			break;
			
		case 7:
			System.out.println();
			System.out.println("Thank You Admin...!!");
			System.exit(0);
	    default :
				System.out.println();
				System.err.println("Please Enter A VALID Option Between [1-7] ...!! ");
				System.out.println();
				callAdminPage();
		}
		}catch (InputMismatchException e) {
			scanner.nextLine();
			System.err.println("  Please enter a numeric value, try again");
			System.out.println();
			callAdminPage();
		}
	}
	
	
	
	private static LoanProgramsBean populateLoanProgramsBean() throws IOException {
        adminService = new AdminService();
		LoanProgramsBean loanProgramsBean = new LoanProgramsBean();
		System.out.println();
		System.out.println("Enter The Loan Program Name : ");
		String programName = buffer.readLine();
		while (true) {
			
			if (adminService.isValidProgramName(programName)) {
				break;
			} else {
				System.err.println("\n Loan Program Name Should Be In Alphabets and minimum 3 and maximum 10 characters long ! Try again");
				programName = buffer.readLine();
			}
		}
		System.out.println("Description about the Loan Program : ");
		String description = buffer.readLine();
      while (true) {
			
			if (adminService.isValidDescription(description)) {
				break;
			} else {
				System.err.println("\n Description Should Be In Alphabets and [3-20] characters long ! Try again");
				description = buffer.readLine();
			}
		}
		System.out.println("Enter the Type of Loan : ");
		System.out.println("1) Purchase \n 2) Construction \n 3) Extension \n 4) Renovation \n Please Choose From Above... !!");
		String type = null;
		try{
		 int option = scanner.nextInt();
		 switch(option){
		 case 1:
			 type = "Purchase";
			 break;
		 case 2:
			 type = "Construction";
			 break;
		 case 3:
			 type = "Extension";
			 break;
		 case 4:
			 type = "Renovation";
			 break;
			 default:
				 System.out.println("Please Enter The Numeric Value Between [1-4]... !!");
				 break;
		 }
		}catch (InputMismatchException e) {
			scanner.nextLine();
			System.err.println("  Please enter a numeric value, try again");
		}
		
		 while (true) {
				
				if (adminService.isValidType(type)) {
					break;
				} else {
					//System.err.println("\n Type would Be Either (Purchase / Construction / Extension / Renovation ). Try again");
					System.err.println("Error Occured ...!! Try Again .... !!");
					System.out.println("Enter the Type of Loan : ");
					System.out.println("1) Purchase \n 2) Construction \n 3) Extension \n 4) Renovation \n Please Choose From Above... !!");
					try{
						 int option = scanner.nextInt();
						 switch(option){
						 case 1:
							 type = "Purchase";
							 break;
						 case 2:
							 type = "Construction";
							 break;
						 case 3:
							 type = "Extension";
							 break;
						 case 4:
							 type = "Renovation";
							 break;
							 default:
								 System.out.println("Please Enter The Numeric Value Between [1-4]... !!");
								 break;
						 }
						}catch (InputMismatchException e) {
							scanner.nextLine();
							System.err.println("  Please enter a numeric value, try again");
						}
				}
			}
		System.out.println("Enter the Duration in Years : ");
		int durationInYears=0;
		try{
		 durationInYears = scanner.nextInt();
		}catch (InputMismatchException inputMismatchException) {
			scanner.nextLine();
			System.err.println("Please enter  numeric value for Duration In Years, try again");
			
			
			}
		while (true) {
			
			if (adminService.isValidDurationInYears(durationInYears)) {
				break;
			} else {
				System.err.println("\n Duration in Years Should Be A Positive Number Upto 10. Try again");
				try{
				durationInYears = scanner.nextInt();
				}catch (InputMismatchException inputMismatchException) {
					scanner.nextLine();
					System.err.println("Please enter  numeric value for Duration In Years, try again");
					
					
					}
			}
		}
		System.out.println("Enter the Minimum Loan Amount : ");
		long minLoanAmount = 0;
		try{
		 minLoanAmount = scanner.nextLong();
		}catch (InputMismatchException inputMismatchException) {
			scanner.nextLine();
			System.err.println("Please enter  numeric value for Minimum Loan Amount, try again");
			}
		 while (true) {
				
				if (adminService.isValidMinLoanAmount(minLoanAmount)) {
					break;
				} else {
					System.err.println("\n Minimum Loan Amount Should Be A Positive Number Upto 2,00,000 . Try again");
					try{
					minLoanAmount = scanner.nextLong();
					}catch (InputMismatchException inputMismatchException) {
						scanner.nextLine();
						System.err.println("Please enter  numeric value for Minimum Loan Amount, try again");
						}
				}
			}
		System.out.println("Enter the Maximum Loan Amount : ");
		long maxLoanAmount = 0;
		try{
		 maxLoanAmount = scanner.nextLong();
		}catch (InputMismatchException inputMismatchException) {
			scanner.nextLine();
			System.err.println("Please enter  numeric value for Maximum Loan Amount, try again");
			}
		 while (true) {
				
				if (adminService.isValidMaxLoanAmount(maxLoanAmount,minLoanAmount)) {
					break;
				} else {
					System.err.println("\n Maximum Loan Amount Should Be Greater Than Minimum Loan Amount Upto 50,00,000  . Try again");
					try{
					maxLoanAmount = scanner.nextLong();
					}catch (InputMismatchException inputMismatchException) {
						scanner.nextLine();
						System.err.println("Please enter  numeric value for Maximum Loan Amount, try again");
						}
				}
			}
		System.out.println("Enter the Rate of Interest : ");
		float rateOfInterest = 0;
		try{
	    rateOfInterest = scanner.nextFloat();
		}catch (InputMismatchException inputMismatchException) {
			scanner.nextLine();
			System.err.println("Please enter  numeric value for Rate Of Interest, try again");
			}
		 while (true) {
				
				if (adminService.isValidRateOfInterest(rateOfInterest)) {
					break;
				} else {
					System.err.println("\n Rate Of Interest Should Be A Positive Number Upto 10. Try again");
					try{
					rateOfInterest = scanner.nextFloat();
					}catch (InputMismatchException inputMismatchException) {
						scanner.nextLine();
						System.err.println("Please enter  numeric value for Rate Of Interest, try again");
						}
				}
			}
		System.out.println("Enter the Proofs Required : ");
		System.out.println("1) Aadhar \n 2) PanCard \n 3) VoterId \n  Please Choose From Above... !!");
		int option = 0;
		String proofsRequired= null;
		try{
			option = scanner.nextInt();
			switch(option){
			case 1:
				proofsRequired = "Aadhar";
				break;
			case 2:
				proofsRequired = "PanCard";
				break;
			case 3:
				proofsRequired = "VoterId";
				break;
				default :
					System.out.println("Enter the option between [1-3] only ... !!");
					break;
				
			}
		}catch (InputMismatchException inputMismatchException) {
			scanner.nextLine();
			System.err.println("Please enter  numeric value only , try again");
			}
		
		 while (true) {
				
				if (adminService.isValidProofsRequired(proofsRequired)) {
					break;
				} else {
					System.err.println("\n Error Occured ...!! Try again");
					System.out.println("Enter the Proofs Required : ");
					System.out.println("1) Aadhar \n 2) PanCard \n 3) VoterId \n  Please Choose From Above... !!");
					try{
						option = scanner.nextInt();
						switch(option){
						case 1:
							proofsRequired = "Aadhar";
							break;
						case 2:
							proofsRequired = "PanCard";
							break;
						case 3:
							proofsRequired = "VoterId";
							break;
							default :
								System.out.println("Enter the option between [1-3] only ... !!");
								break;
							
						}
					}catch (InputMismatchException inputMismatchException) {
						scanner.nextLine();
						System.err.println("Please enter  numeric value only , try again");
						}
				}
			}
		loanProgramsBean.setProgramName(programName);
		loanProgramsBean.setDescription(description);
		loanProgramsBean.setType(type);
		loanProgramsBean.setDurationInYears(durationInYears);
		loanProgramsBean.setMinLoanAmount(minLoanAmount);
		loanProgramsBean.setMaxLoanAmount(maxLoanAmount);
		loanProgramsBean.setRateOfInterest(rateOfInterest);
		loanProgramsBean.setProofsRequired(proofsRequired);
		return loanProgramsBean;
		
	}


}
