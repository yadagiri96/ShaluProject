package com.capgemini.laps.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.laps.bean.ApprovedLoansBean;
import com.capgemini.laps.bean.LoanApplicationBean;
import com.capgemini.laps.exception.LoanException;
import com.capgemini.laps.service.ILADService;
import com.capgemini.laps.service.LADService;

public class LAD {

	
	static ILADService ladService = null;
	static Scanner scanner = new Scanner(System.in);
	static LoanApplicationBean loanApplicationBean=null;
	static ApprovedLoansBean approvedLoansBean = null;
	static Logger logger = Logger.getRootLogger();
	static BufferedReader buffer = new BufferedReader(new InputStreamReader(System.in));
	static int appId = 0;
	
	static void callLadPage() throws IOException {

		System.out.println();
		System.out.println("-------------------------------------------------------------------");
		System.out.println();
		System.out.println("1) View All Loan Programs Offered by the Home Finance Provider.");
		System.out.println("2) View Loan Application for a Specific Loan Program . ");
		System.out.println("3) Modify The Loan Application Status. ");
		//System.out.println("4) After Interview Application Approval .  ");
		//System.out.println("4) Go Back To The Home Page . ");
		System.out.println("4) LogOut..!! ");
		System.out.println("5) Exit .. !! ");
		System.out.println();
		System.out.println("-------------------------------------------------------------------");
		
		System.out.println("Please Choose An Option Given Above.  ");
		try{
			
			int ladOption = scanner.nextInt();
			switch(ladOption){
			case 1:
				System.out.println();
				System.out.println("Loan Programs Provided By Home Finance Provider Are ----- ");
				System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
				System.out.println();
				User.viewPrograms();
				System.out.println();
				System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
				System.out.println();
				callLadPage();
				break;
				
			case 2:
				String reply =  null;
				System.out.println();
				System.out.println("Loan Programs Provided By Home Finance Provider Are ----- ");
				System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
				System.out.println();
				User.viewPrograms();
				System.out.println();
				System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
				System.out.println();
				do{
				System.out.println("Please Enter The Loan Program Name : ");
				String loanProgram = buffer.readLine();
				ladService = new LADService();
				
				List<LoanApplicationBean> loanApplicationList = new ArrayList<LoanApplicationBean>();
				try {
					loanApplicationList = ladService.viewApplications(loanProgram);
				

				if (loanApplicationList != null) {
					System.out.println();
					System.out.println("------------------------------------");
					System.out.println("Available Loan Applications Are : ");
					System.out.println();
					System.out.println("*******************************************************************************************************************************");
					System.out.println("*******************************************************************************************************************************");
					System.out.println();
					Iterator<LoanApplicationBean> i = loanApplicationList.iterator();
					while (i.hasNext()) {
						System.out.println(i.next());
					}
					System.out.println();
					System.out.println("*******************************************************************************************************************************");
					System.out.println("*******************************************************************************************************************************");
				} else {
					System.err.println("No loan Application available of this Loan Program...!!");
					
				}
				}catch (LoanException e) {

					System.out.println("Error  :" + e.getMessage());
				}
				
				System.out.println();
				System.out.println("Do You Want To Continue Searching The Loan Application ??  Reply with  Yes / No...!!");
				reply = buffer.readLine();
				while(true){
					if(ladService.isValidReply(reply))
						break;
					else{
						System.out.println("Reply will be Yes / No Only ... !!");
						reply = buffer.readLine();
					}
				}
				}while("YES".equals(reply.toUpperCase()));
				callLadPage();
				break;
				
			case 3:
				ladService = new LADService();
				String dateOfInterview = null;
				do{
				System.out.println();
				System.out.println("Enter The Application Id to Accept or Reject or Approve That Application : ");
				try{
				 appId = scanner.nextInt();
				}catch(InputMismatchException e) {
					scanner.nextLine();
					System.err.println("Please enter a numeric value for Application Id. ");
				}
				while (true) {
					
					if (ladService.isValidApplicationId(appId)) {
						break;
					} else {
						System.err.println(" Try again");
						appId = scanner.nextInt();
					}
				}
					String currentStatus = ladService.getCurrentStatus(appId);
					
					if ("Rejected".equals(currentStatus) || "Approved".equals(currentStatus)){
						System.out.println("You Can't Modify The Status Further... Loan Application Has Been Already "+currentStatus);
					}
					else{
						
					System.out.println("The Current Application Status is "+currentStatus);
					int option =0;
					String status = null;
					if("Applied".equals(currentStatus)){
				System.out.println("Enter the  Status You Want  To Modify As : ");
					System.out.println("1. Accepted \n 2. Rejected \n Please Choose From Above Options... !!");
					
					try{
						option = scanner.nextInt();
						switch(option){
						case 1:
							status = "Accepted";
							break;
						case 2:
							status = "Rejected";
							break;
							default:
								System.out.println("Enter Either 1 or 2.. !!");
						}
					}catch (InputMismatchException e) {
						scanner.nextLine();
						System.err.println("Please enter the numeric value, try again");
					}
				
				while (true){
					if(ladService.isValidApplicationStatus(status,currentStatus)){
						break;
					}else {
						System.err.println(" Application Status Could Be Modified Only As (Accepted / Rejected ) ... !! ");
						System.out.println("Enter the  Status You Want  To Modify As : ");
						System.out.println("1. Accepted \n 2. Rejected \n Please Choose From Above Options... !!");
						
						try{
							option = scanner.nextInt();
							switch(option){
							case 1:
								status = "Accepted";
								break;
							case 2:
								status = "Rejected";
								break;
								default:
									System.out.println("Enter Either 1 or 2.. !!");
							}
						}catch (InputMismatchException e) {
							scanner.nextLine();
							System.err.println("Please enter the numeric value, try again");
						}
					}
					
				}
				dateOfInterview = ladService.modifyApplicationStatus(appId,status);
				if(dateOfInterview != null){
					System.out.println("The Loan Application Having Application Id "+appId+" Has Been "+status+" , And The Date Of Interview Is "+dateOfInterview);
				}
					}
				else if("Accepted".equals(currentStatus)){
					System.out.println("Enter the  Status You Want  To Modify As : ");
					System.out.println("1. Approved \n 2. Rejected \n Please Choose From Above Options... !!");
					
					try{
						option = scanner.nextInt();
						switch(option){
						case 1:
							status = "Approved";
							break;
						case 2:
							status = "Rejected";
							break;
							default:
								System.out.println("Enter Either 1 or 2.. !!");
						}
					}catch (InputMismatchException e) {
						scanner.nextLine();
						System.err.println("Please enter the numeric value, try again");
					}
				
				while (true){
					if(ladService.isValidApplicationStatus(status,currentStatus)){
						break;
					}else {
						System.err.println(" Application Status Could Be Modified Only As (Approved / Rejected ) ... !! ");
						System.out.println("Enter the  Status You Want  To Modify As : ");
						System.out.println("1. Approved \n 2. Rejected \n Please Choose From Above Options... !!");
						
						try{
							option = scanner.nextInt();
							switch(option){
							case 1:
								status = "Approved";
								break;
							case 2:
								status = "Rejected";
								break;
								default:
									System.out.println("Enter Either 1 or 2.. !!");
							}
						}catch (InputMismatchException e) {
							scanner.nextLine();
							System.err.println("Please enter the numeric value, try again");
						}
					}
					
				}
				dateOfInterview = ladService.modifyApplicationStatus(appId,status);
				
				 if("Approved".equals(status)){

					 System.out.println(+appId);
					 
						approvedLoansBean = populateApprovedLoanBean(appId);
					try{
					ladService = new LADService();
					boolean added =ladService.addApprovedLoansDetails(approvedLoansBean);
				if(added == true)
					System.out.println("Approved Loans Details Added Successfully... !!");
				else
					System.err.println("Error Occured While Inserting Approved Loans Details... !!");
					}catch (Exception e){
						System.err.println("Loan Application ERROR : "+ e.getMessage());
					}
				 }
				}
					}
				
					
					System.out.println();
					System.out.println("Do You Want To Continue Modifying The Loan Application Status ??  Reply with  Yes / No...!!");
					reply = scanner.next();
					while(true){
						if(ladService.isValidReply(reply))
							break;
						else{
							System.out.println("Reply will be Yes / No Only ... !!");
							reply = buffer.readLine();
						}
					}
					}while("YES".equals(reply.toUpperCase()));
				System.out.println();
				callLadPage();
			break;

			
			case 4:
				System.out.println("You Logged Out Successfully... !! ");
				System.out.println();
				User.logout();
				
				break;
			case 5:
				System.out.println();
				System.out.println("Thank You Member Of Loan Approval Department...!!");
				System.exit(0);
		    default :
					System.out.println();
					System.err.println("Please Enter A VALID Option Between [1-5] ...!! ");
					System.out.println();
					callLadPage();
			}
		}catch (InputMismatchException  e) {
			scanner.nextLine();
			System.err.println(" 2 Please enter a numeric value, try again");
			System.out.println();
			callLadPage();
		} catch (LoanException e1) {

			System.out.println("Error  :" + e1.getMessage());
		}
	}

	private static ApprovedLoansBean populateApprovedLoanBean(int appId) {
		ladService = new LADService();
		approvedLoansBean = new ApprovedLoansBean();
		String customerName = ladService.getCustomerName(appId);
		long amountOfLoanGranted = ladService.getAmountOfLoanGranted(appId);
		int yearsTimePeriod = ladService.getYearsTimePeriod(appId);
		double downpayment = amountOfLoanGranted /10;
		float rateOfInterest = ladService.getRateOfInterest(appId);
		double monthlyInstallment = (amountOfLoanGranted - downpayment) * rateOfInterest * 1.5 / (yearsTimePeriod * 12* 10);
		double totalAmountPayable = (monthlyInstallment * 12 * yearsTimePeriod) + downpayment;
		
		approvedLoansBean.setCustomerName(customerName);
		approvedLoansBean.setAmountOfLoanGranted(amountOfLoanGranted);
		approvedLoansBean.setMonthlyInstallment(monthlyInstallment);
		approvedLoansBean.setYearsTimePeriod(yearsTimePeriod);
		approvedLoansBean.setDownpayment(downpayment);
		approvedLoansBean.setRateOfInterest(rateOfInterest);
		approvedLoansBean.setTotalAmountPayable(totalAmountPayable);
		return approvedLoansBean;
	}


}
