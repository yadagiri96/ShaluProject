package com.capgemini.laps.ui;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;













import org.apache.log4j.Logger;

import com.capgemini.laps.bean.CustomerDetailsBean;
import com.capgemini.laps.bean.LoanApplicationBean;
import com.capgemini.laps.bean.LoanProgramsBean;
import com.capgemini.laps.exception.LoanException;
//import com.capgemini.laps.service.AdminService;
import com.capgemini.laps.service.CustomerService;
import com.capgemini.laps.service.IAdminService;
import com.capgemini.laps.service.ICustomerService;
import com.capgemini.laps.service.ILADService;
import com.capgemini.laps.service.ILoanProgramsService;
//import com.capgemini.laps.service.LADService;
import com.capgemini.laps.service.LoanProgramsService;



public class User {

	static ILoanProgramsService loanProgramsService=null;
	static IAdminService adminService=null;
    static ILADService ladService = null;
	static ICustomerService customerService = null;
	static Scanner scanner = new Scanner(System.in);
	static LoanApplicationBean loanApplicationBean=null;
	static CustomerDetailsBean customerBean=null;
	static  LoanProgramsBean loanProgramsBean = null;
	static Logger logger = Logger.getRootLogger();
	static BufferedReader buffer = new BufferedReader(new InputStreamReader(System.in));
	static int appId = 0;
	public static void main(String[] args) throws IOException {
		
		callHomePage();
		
		}
		
	
	//------------------------ 1. Loan Application Processing System --------------------------
	/*******************************************************************************************************
	 - Function Name	:	callHomePage()
	 - Input Parameters	:	No Argument
	 - Return Type		:	void
	 - Throws           :   IOException
	 - Author			:	Shalu Kumari
	 - Creation Date	:	27/08/2018
	 - Description		:	Getting Customer's Functionality.
	
	 ********************************************************************************************************/

	

	public static void callHomePage() throws IOException {

		System.out.println();
		System.out.println("*************************************************************");
		System.out.println("<----- Welcome To Loan Application Processing System ----->");
		System.out.println("*************************************************************");
		System.out.println();
		System.out.println("--------------------------------------------------------------");
		System.out.println("1) Login Form ");
		System.out.println("2) View all the Available Loan Programs : ");
		System.out.println("3) Apply For Loan Program : ");
		System.out.println("4) Search The Application Status Using Your Application Id : ");
		System.out.println("5) Exit. ");
		System.out.println("--------------------------------------------------------------");
		System.out.println();
		System.out.println("Enter Your Choice !! ");
		System.out.println();
		try{
		int choice = scanner.nextInt();
		switch(choice){
		case 1:
			String logid = null;
			String pwd = null;
			String role = null;
			System.out.println();
			System.out.println("====================");
			System.out.println("Enter Login Id : ");
		    logid=scanner.next();
			System.out.println("Enter Password ");
			pwd=scanner.next();
			System.out.println("====================");
			
			role=login(logid,pwd);
			int count = 0;
			while(true){
				if(role != null)
					break;
				else{
					System.out.println();
					System.out.println("====================");
					System.out.println("Enter Login Id : ");
					logid=scanner.next();
					System.out.println("Enter Password ");
					pwd=scanner.next();
					System.out.println("====================");
					
					role=login(logid,pwd);
					count++;
					if(count>1  && role==null){
						System.out.println("You Have Entered The Incorrect Credentials Consequently 3 Times. Can't Login Now...!!");
						logger.error("You Have Entered The Incorrect Credentials Consequently 3 Times. Can't Login Now...!!");
						callHomePage();
					}
				}
			}
			getRole(role);
			break;
			
		case 2:
			System.out.println();
			System.out.println("Loan Programs Provided By Home Finance Provider Are ----- ");
			System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
			viewPrograms();
			System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
			System.out.println();
			callHomePage();
			break;
			
		case 3:
			int applicationId = 0;
			loanProgramsService = new LoanProgramsService();
			try {
				if(loanProgramsService.displayAll() != null){
					//System.out.println();
					//System.out.println();
					//System.out.println("******* Apply for a Loan Program *******");
					
						loanApplicationBean = populateLoanApplicationBean();
						
					try{
					customerService = new CustomerService();
					applicationId=customerService.addApplicationDetails(loanApplicationBean);
					System.out.println();
					System.out.println("Loan Application has been filled successfully with the Application id :  "+applicationId);
					logger.info("Loan Application has been filled successfully with the Application id :  "+applicationId);
					}catch (Exception e){
						System.err.println("Loan Application ERROR : "+ e.getMessage());
					}
					if(applicationId != 0){
					while (customerBean == null) {
						customerBean = populateCustomerDetailsBean(applicationId);
					}
					try{
					boolean add= customerService.addCustomerDetails(customerBean);
					
					if(add==true){
						System.out.println();
						System.out.println("*************************************");
						System.out.println(" Customer Deatils Added SuccessFully ");
						logger.info("Customer Deatils Added SuccessFully");
						System.out.println("*************************************");
					}else{
						System.out.println();
						System.out.println("***********************************");
						System.err.println(" Customer Details Insertion Failed ");
						logger.error("Customer Details Insertion Failed");
						System.out.println("***********************************");
					}
					}catch (Exception e){
						System.err.println("Customer Details ERROR : "+ e.getMessage());
					}
					}
					
				}
			} catch (LoanException e) {

				e.printStackTrace();
			} 
			System.out.println();
			callHomePage();
			break;
			
		case 4:
			
			customerService = new CustomerService();
			System.out.println();
			System.out.println("Enter Your Application Id : ");
			try{
			 appId = scanner.nextInt();
			}catch(InputMismatchException e) {
				scanner.nextLine();
				System.err.println("Please enter a numeric value for Application Id. ");
				logger.error("Please enter a numeric value for Application Id. ");
			}
			while (true) {
				
				if (customerService.isValidApplicationId(appId)) {
					break;
				} else {
					System.err.println(" Try again");
					try{
					appId = scanner.nextInt();
					}catch(InputMismatchException e) {
						scanner.nextLine();
						System.err.println("Please enter a positive no for Application Id Upto 1,00,000  . ");
						logger.error("Please enter a positive no for Application Id Upto 1,00,000  . ");
					}
				}
			}
			String applicationStatus = customerService.getApplicationStatus(appId);
			
			if(applicationStatus==null){
				System.err.println("Please Enter The Valid Application Id .");
				
			}
			else{
				System.out.println("Your Current Application Status is - "+applicationStatus);
				logger.info("Your Current Application Status is - "+applicationStatus);
			}
			System.out.println();
		
		callHomePage();
		break;
		
		case 5:
			
			System.out.println();
			System.out.println("Thank you User...!!");
			logger.info("Thank you User...!!");
			System.exit(0);
			break;

			default :
				System.out.println();
				System.err.println("Please Enter A VALID Choice , Between [1-5]... !! ");
				logger.error("Please Enter A VALID Choice , Between [1-5]... !! ");
				System.out.println();
				callHomePage();
			
		}
		}catch(InputMismatchException e) {
			scanner.nextLine();
			System.err.println("Please enter a numeric value, try again");
			logger.error("Please enter a numeric value, try again");
			System.out.println();
			callHomePage();
		} catch (LoanException e) {
			System.out.println("Error  :" + e.getMessage());
		}
		
	}


	//------------------------ 1. Loan Application Processing System --------------------------
		/*******************************************************************************************************
		 - Function Name	:	getRole(String role)
		 - Input Parameters	:	String role
		 - Return Type		:	void
		 - Throws           :   IOException
		 - Author			:	Shalu Kumari
		 - Creation Date	:	27/08/2018
		 - Description		:	According to role going either on Admin page or on Lad Page.
		
		 ********************************************************************************************************/



	public static void getRole(String role) throws IOException {

		//if(role == null){
		//	System.err.println("Please Enter the Correct Credentials... !! ");
		//	System.out.println("===========================================");
		//	System.out.println();
		//	callHomePage();
			
		//}else{
			if("admin".equals(role)){
				System.out.println();
				System.out.println("**********************");
				System.out.println("Login Successful !! ");
				logger.info("Login Successful !! ");
				System.out.println("Welcome Admin..... !! ");
				System.out.println("**********************");
				Admin.callAdminPage();
				
			}else{
				System.out.println();
				System.out.println();
				System.out.println("****************************************************");
				System.out.println("Login Successful... !!");
				logger.info("Login Successful... !!");
				System.out.println("Welcome Members of Loan Approval Department (LAD) ");
				System.out.println("****************************************************");
				System.out.println();
				
				LAD.callLadPage();
				
			}
		
		
	}


	

	





	public static String login(String logid, String pwd) throws LoanException {

		loanProgramsService = new LoanProgramsService();
		return loanProgramsService.login(logid,pwd);
		
	}




	//------------------------ 1. Loan Application Processing System --------------------------
		/*******************************************************************************************************
		 - Function Name	:	populateCustomerDetailsBean(int applicationId)
		 - Input Parameters	:	int applicationId
		 - Return Type		:	CustomerDetailsBean
		 - Throws			:  	LoanException
		 - Author			:	Shalu Kumari
		 - Creation Date	:	27/08/2018
		 - Description		:	Populating The Customer Details Bean.
		 ********************************************************************************************************/



	private static CustomerDetailsBean populateCustomerDetailsBean(int applicationId) throws IOException {
         customerService = new CustomerService();
		CustomerDetailsBean customerBean = new CustomerDetailsBean();
		System.out.println();
		System.out.println();
		System.out.println(" ***** Enter Your Personal Details Below : ");
		System.out.println();
		
		
		System.out.println("Your Application Id is : "+applicationId);
		System.out.println("Enter Your Name : ");
		String applicantName = buffer.readLine();
		 while (true) {
				
				if (customerService.isValidApplicantName(applicantName)){
					break;
				} else {
					System.err.println("\n Applicant Name Should Contain Only Alphabets And Space and It Should Be [3-20] Characters Long . Try again");
					applicantName = buffer.readLine();
				}
			}
		System.out.println("Enter Your Date Of Birth (DD/MM/YYYY) : ");
		String dateOfBirth = scanner.next();
		 while (true) {
				
				if (customerService.isValidDateOfBirth(dateOfBirth)){
					break;
				} else {
					System.err.println("\n Date Of Birth Should Be of in this Format - DD/MM/YYYY . Try again");
					dateOfBirth = scanner.next();
				}
			}
		System.out.println("Enter Your Marital Status : \n 1. Married \n 2. Unmarried \n Choose From Above... : ");
		int option = 0;
		String maritalStatus = null;
		try{
			option = scanner.nextInt();
			switch(option){
			case 1:
				maritalStatus = "Married";
				break;
			case 2:
				maritalStatus = "Unmarried";
				break;
				default :
					System.out.println("Please A Numeric Value Either 1 Or 2 ... !!");
					break;
			}
		}catch (InputMismatchException inputMismatchException) {
			scanner.nextLine();
			System.err.println("Please enter  numeric value only , try again");
			}
		
		while (true) {
			
			if (customerService.isValidMaritalStatus(maritalStatus)){
				break;
			} else {
				System.err.println("\n Marital Status Should Be Married or Unmarried Only. ! Try again");

				System.out.println("Enter Your Marital Status : \n 1. Married \n 2. Unmarried \n Choose From Above... : ");
				try{
					option = scanner.nextInt();
					switch(option){
					case 1:
						maritalStatus = "Married";
						break;
					case 2:
						maritalStatus = "Unmarried";
						break;
						default :
							System.out.println("Please A Numeric Value Either 1 Or 2 ... !!");
							break;
					}
				}catch (InputMismatchException inputMismatchException) {
					scanner.nextLine();
					System.err.println("Please enter  numeric value only , try again");
					}
			}
		}
		System.out.println("Enter Your Phone Number : ");
		long phoneNumber = 0;
		try{
		phoneNumber = scanner.nextLong();
		}catch (InputMismatchException inputMismatchException) {
			scanner.nextLine();
			System.err.println("Please enter  numeric value for Phone Number, try again");
			}
        while (true) {
			
			if (customerService.isValidPhoneNumber(phoneNumber)){
				break;
			} else {
				System.err.println("\n Phone Number Should Be of 10 Digits And Should Start With 7 or 8 or 9. ! Try again");
				try{
				phoneNumber = scanner.nextLong();
				}catch (InputMismatchException inputMismatchException) {
					scanner.nextLine();
					System.err.println("Please enter  numeric value for Phone Number, try again");
					}
			}
		}
		System.out.println("Enter Your Mobile No : ");
		long mobileNumber = 0;
		try{
		mobileNumber = scanner.nextLong();
		}catch (InputMismatchException inputMismatchException) {
			scanner.nextLine();
			System.err.println("Please enter a numeric value for Mobile Number, try again");
			}
		 while (true) {
				
				if (customerService.isValidMobileNumber(mobileNumber,phoneNumber)){
					break;
				} else {
					System.err.println("\n Mobile  Number Should Be of 10 Digits And Should Start With 7 or 8 or 9. ! Try again");
					try{
					mobileNumber = scanner.nextLong();
					}catch (InputMismatchException inputMismatchException) {
						scanner.nextLine();
						System.err.println("Please enter a numeric value for Mobile Number, try again");
						}
				}
			}
		System.out.println("Enter the Count Of Dependents : ");
		int countOfDependents = 0;
		try{
	      countOfDependents = scanner.nextInt();
		}catch (InputMismatchException inputMismatchException) {
			scanner.nextLine();
			System.err.println("Please enter a numeric value for Count Of Dependents, try again");
			}
		 while (true) {
				
				if (customerService.isValidCountOfDependents(countOfDependents)){
					break;
				} else {
					System.err.println("\n Count Of Dependents Should Be A Positive Number Upto 10. Try again");
					try{
					countOfDependents = scanner.nextInt();
					}catch (InputMismatchException inputMismatchException) {
						scanner.nextLine();
						System.err.println("Please enter a numeric value for Count Of Dependents, try again");
						}
				}
			}
		System.out.println("Enter Your Email Id : ");
		String emailId = buffer.readLine();
		while (true) {
			
			if (customerService.isValidEmailId(emailId)){
				break;
			} else {
				System.err.println("\n Email Id Should Be Of This Format --> abc@gh.com  And Should Be Maximum 20 Characters Long. Try again");
				emailId = buffer.readLine();
			}
		}
		
		customerBean.setApplicationId(applicationId);
		customerBean.setApplicantName(applicantName);
		customerBean.setDateOfBirth(dateOfBirth);
		customerBean.setMaritalStatus(maritalStatus);
		customerBean.setPhoneNumber(phoneNumber);
		customerBean.setMobileNumber(mobileNumber);
		customerBean.setCountOfDependents(countOfDependents);
		customerBean.setEmailId(emailId);
		
		return customerBean;
		}

	
	
	//------------------------ 1. Loan Application Processing System --------------------------
			/*******************************************************************************************************
			 - Function Name	:	populateLoanApplicationBean()
			 - Input Parameters	:	No Input Parameters.
			 - Return Type		:	LoanApplicationBean
			 - Throws			:  	LoanException
			 - Author			:	Shalu Kumari
			 - Creation Date	:	27/08/2018
			 - Description		:	Populating The Loan Application Bean.
			 ********************************************************************************************************/

	
	private static LoanApplicationBean populateLoanApplicationBean() throws IOException {
         customerService = new CustomerService();
		LoanApplicationBean loanApplicationBean = new LoanApplicationBean();
		System.out.println();
		System.out.println();
		System.out.println("***** Fill for the Loan Application form *****");
		System.out.println();
		System.out.println("Enter the Loan Program Name : ");
		String loanProgram = buffer.readLine();
        while (true) {
			
			if (customerService.isValidLoanProgram(loanProgram)) {
				break;
			} else {
				System.err.println("\n Loan Program Name Should Be In Alphabets and [3-10] characters long ! Try again");
				loanProgram =buffer.readLine();
			}
		}
		System.out.println("Enter the Amount of Loan : ");
		long amountOfLoan = 0;
		try{
		amountOfLoan=scanner.nextLong();
		}catch (InputMismatchException inputMismatchException) {
			scanner.nextLine();
			System.err.println("Please enter a numeric value for Amount Of Loan, try again");
			}
		 while (true) {
				
				if (customerService.isValidAmountOfLoan(amountOfLoan)){
					break;
				} else {
					System.err.println("\n Amount Of Loan Should Be A Positive Number Upto 50,00,000 ... ! Try again");
					try{
					amountOfLoan= scanner.nextLong();
					}catch (InputMismatchException inputMismatchException) {
						scanner.nextLine();
						System.err.println("Please enter a numeric value for Amount Of Loan, try again");
						}
				}
			}
		System.out.println("Enter the Address of Property : ");
		String addressOfProperty = buffer.readLine();
		 while (true) {
				
				if (customerService.isValidAddressOfProperty(addressOfProperty)){
					break;
				} else {
					System.err.println("\n Address Of Property Should Be [3-20] characters long ! Try again");
					addressOfProperty = buffer.readLine();
				}
			}
		System.out.println("Enter Annual Family Income : ");
		long annualFamilyIncome = 0;
		try{
		annualFamilyIncome = scanner.nextLong();
		}catch (InputMismatchException inputMismatchException) {
			scanner.nextLine();
			System.err.println("Please enter a numeric value for Annual Family Income, try again");
			}
		while (true) {
			
			if (customerService.isValidAnnualFamilyIncome(annualFamilyIncome)){
				break;
			} else {
				System.err.println("\n Annual Family Income Should be A Positive Number Upto 1,00,00,000  ..... ! Try again");
				try{
				annualFamilyIncome = scanner.nextLong();
				}catch (InputMismatchException inputMismatchException) {
					scanner.nextLine();
					System.err.println("Please enter a numeric value for Annual Family Income, try again");
					}
			}
		}
		System.out.println("Enter Document Proofs Available : ");
		System.out.println("1) Aadhar \n 2) PanCard \n 3) VoterId \n  Please Choose From Above... !!");
		int option = 0;
		String documentProofsAvailable= null;
		try{
			option = scanner.nextInt();
			switch(option){
			case 1:
				documentProofsAvailable = "Aadhar";
				break;
			case 2:
				documentProofsAvailable = "PanCard";
				break;
			case 3:
				documentProofsAvailable = "VoterId";
				break;
				default :
					System.out.println("Enter the option between [1-3] only ... !!");
					break;
				
			}
		}catch (InputMismatchException inputMismatchException) {
			scanner.nextLine();
			System.err.println("Please enter  numeric value only , try again");
			}
		
		 while (true) {
				
				if (customerService.isValidDocumentProofsAvailable(documentProofsAvailable)) {
					break;
				} else {
					System.err.println("\n Error Occured ...!! Try again");
					System.out.println("Enter Document Proofs Available : ");
					System.out.println("1) Aadhar \n 2) PanCard \n 3) VoterId \n  Please Choose From Above... !!");
					try{
						option = scanner.nextInt();
						switch(option){
						case 1:
							documentProofsAvailable = "Aadhar";
							break;
						case 2:
							documentProofsAvailable = "PanCard";
							break;
						case 3:
							documentProofsAvailable = "VoterId";
							break;
							default :
								System.out.println("Enter the option between [1-3] only ... !!");
								break;
							
						}
					}catch (InputMismatchException inputMismatchException) {
						scanner.nextLine();
						System.err.println("Please enter  numeric value only , try again");
						}
				}
			}
		System.out.println("Enter the Guarantee Cover : ");
		String guaranteeCover = buffer.readLine();
		 while (true) {
				
				if (customerService.isValidGuaranteeCover(guaranteeCover)){
					break;
				} else {
					System.err.println("\n Guarantee Cover  Should Be In Alphabets and [3-20] characters long ! Try again");
					guaranteeCover = buffer.readLine();
				}
			}
		System.out.println("Enter the Market Value of Guarantee Cover : ");
		int marketValueOfGuaranteeCover = 0;
		try{
		marketValueOfGuaranteeCover = scanner.nextInt();
		}catch (InputMismatchException inputMismatchException) {
			scanner.nextLine();
			System.err.println("Please enter a numeric value for Market Value Of Guarantee Cover, try again");
			}
		while (true) {
			
			if (customerService.isValidMarketValueOfGuaranteeCover(marketValueOfGuaranteeCover)){
				break;
			} else {
				System.err.println("\n Market Value Of The Guarantee Cover Should be A Positive Number Upto 5,00,00,000  ...! Try again");
				try{
				marketValueOfGuaranteeCover = scanner.nextInt();
				}catch (InputMismatchException inputMismatchException) {
					scanner.nextLine();
					System.err.println("Please enter a numeric value for Market Value Of Guarantee Cover, try again");
					}
			}
		}
		
		loanApplicationBean.setLoanProgram(loanProgram);
		loanApplicationBean.setAmountOfLoan(amountOfLoan);
		loanApplicationBean.setAddressOfProperty(addressOfProperty);
		loanApplicationBean.setAnnualFamilyIncome(annualFamilyIncome);
		loanApplicationBean.setDocumentProofsAvailable(documentProofsAvailable);
		loanApplicationBean.setGuaranteeCover(guaranteeCover);
		loanApplicationBean.setMarketValueOfGuaranteeCover(marketValueOfGuaranteeCover);
		
		
		return loanApplicationBean;
		}

	
	//------------------------ 1. Loan Application Processing System --------------------------
	/*******************************************************************************************************
	 - Function Name	:	viewPrograms()
	 - Input Parameters	:	No Input Parameters.
	 - Return Type		:	void
	 - Throws			:  	LoanException
	 - Author			:	Shalu Kumari
	 - Creation Date	:	27/08/2018
	 - Description		:	Viewing Loan Programs.
	 ********************************************************************************************************/
	
	public static void viewPrograms()
	{
		 loanProgramsService = new LoanProgramsService();
		try {
			List<LoanProgramsBean> loanProgramsList = new LinkedList<LoanProgramsBean>();
			loanProgramsList = loanProgramsService.displayAll();

			if (loanProgramsList != null) {
				Iterator<LoanProgramsBean> i = loanProgramsList.iterator();
				while (i.hasNext()) {
					System.out.println(i.next());
				}
				/*System.out.println("Loan Programs" );
				//Iterator<LoanProgramsBean> i = loanProgramsList.iterator();
				
				for(LoanProgramsList list:  ) {
					System.out.println(loanProgramsList.);*/
			}else {
				System.out.println("No loan program available.");
			}

	}

	catch (LoanException e) {

			System.out.println("Error  :" + e.getMessage());
		}
		
	}
	
	//------------------------ 1. Loan Application Processing System --------------------------
		/*******************************************************************************************************
		 - Function Name	:	logout()
		 - Input Parameters	:	No Input Parameters.
		 - Return Type		:	void
		 - Throws			:  	IOException
		 - Author			:	Shalu Kumari
		 - Creation Date	:	27/08/2018
		 - Description		:	Logout From A Specific Location.
		 ********************************************************************************************************/
	
	public static void logout() throws IOException
	{
		String logid = null;
		String pwd = null;
		String role = null;
		System.out.println("\n 1) Login Form. \n 2) Back To Home Page. \n Choose An Option... !! ");
		int option = 0;
		try{
			option = scanner.nextInt();
			switch(option){
			case 1:
				System.out.println();
				System.out.println("====================");
				System.out.println("Enter Login Id : ");
			    logid=buffer.readLine();
				System.out.println("Enter Password ");
				pwd=buffer.readLine();
				System.out.println("====================");
				
				role=User.login(logid,pwd);
				int count = 0;
				while(true){
					if(role != null)
						break;
					else{
						System.out.println();
						System.out.println("====================");
						System.out.println("Enter Login Id : ");
						logid=buffer.readLine();
						System.out.println("Enter Password ");
						pwd=buffer.readLine();
						System.out.println("====================");
						
						role=User.login(logid,pwd);
						count++;
						if(count>1 && role==null){
							System.out.println("You Have Entered The Incorrect Credentials Consequently 3 Times. Can't Login Now...!!");
							callHomePage();
						}
					}
				}
			    getRole(role);
				break;
				
			case 2:
				callHomePage();
				break;
				default :
					System.err.println("Enter Either 1 or 2 only ...!!");
					logout();
					break;
			}
		}catch (InputMismatchException e) {
			scanner.nextLine();
			System.err.println("  Please enter a numeric value, try again");
			logout();
		} catch (LoanException e) {
			System.out.println("Error  :" + e.getMessage());
		}
		
	}
	
	

}
