package com.capgemini.laps.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.laps.bean.ApprovedLoansBean;
import com.capgemini.laps.bean.LoanApplicationBean;
import com.capgemini.laps.dbutil.DBConnection;
import com.capgemini.laps.exception.LoanException;

public class LADDAO implements ILADDAO {

	
	Connection con=null;
	PreparedStatement ps=null;
	ResultSet resultset = null;
	
	
	//------------------------ 1. Loan Application Processing System --------------------------
	/*******************************************************************************************************
	 - Function Name	:	viewApplications(String loanProgram)
	 - Input Parameters	:	String loanProgram
	 - Return Type		:	List<LoanApplicationBean>
	 - Throws			:  	LoanException
	 - Author			:	Shalu Kumari
	 - Creation Date	:	27/08/2018
	 - Description		:	Viewing all Loan Applications on the Basis Of loan Program.
	 ********************************************************************************************************/



	@Override
	public List<LoanApplicationBean> viewApplications(String loanProgram) throws LoanException{
		int loanApplicationCount = 0;
		try {
			con = DBConnection.establishConnection();
			List<LoanApplicationBean> loanApplicationList = new ArrayList<LoanApplicationBean>();
			ps = con.prepareStatement(IQueryMapper.VIEW_LOAN_APPLICATION_ON_THE_BASIS_OF_LOANPROGRAM);
			ps.setString(1, loanProgram);
			resultset = ps.executeQuery();
			
			while(resultset.next()){
				LoanApplicationBean loanApplicationBean = new LoanApplicationBean();
				loanApplicationBean.setApplicationId(resultset.getInt(1));
				loanApplicationBean.setApplicationDate(resultset.getDate(2));
				loanApplicationBean.setLoanProgram(resultset.getString(3));
				loanApplicationBean.setAmountOfLoan(resultset.getLong(4));
				loanApplicationBean.setAddressOfProperty(resultset.getString(5));
				loanApplicationBean.setAnnualFamilyIncome(resultset.getLong(6));
				loanApplicationBean.setDocumentProofsAvailable(resultset.getString(7));
				loanApplicationBean.setGuaranteeCover(resultset.getString(8));
				loanApplicationBean.setMarketValueOfGuaranteeCover(resultset.getInt(9));
				loanApplicationBean.setStatus(resultset.getString(10));
				loanApplicationBean.setDateOfInterview(resultset.getDate(11));
				
				loanApplicationList.add(loanApplicationBean);
				loanApplicationCount++;
				
			}
			
			if(loanApplicationCount == 0){
				return null;
			}else
				return loanApplicationList;
		} catch (SQLException sqlException) {
			throw new LoanException("Exception: "+sqlException.getMessage());
		}
		
		
	}


	//------------------------ 1. Loan Application Processing System --------------------------
	/*******************************************************************************************************
	 - Function Name	:	modifyApplicationStatus(int appId,String status)
	 - Input Parameters	:	int appId,String status
	 - Return Type		:	String
	 - Throws			:  	LoanException
	 - Author			:	Shalu Kumari
	 - Creation Date	:	27/08/2018
	 - Description		:	Modifying the Loan Application Status.
	 ********************************************************************************************************/



	@Override
	public String modifyApplicationStatus(int appId,String status) throws LoanException {
		int queryResult =0;
		int qResult =0;
		try {
			con = DBConnection.establishConnection();
			
			
			
			ps= con.prepareStatement(IQueryMapper.MODIFY_APPLICATION_STATUS);
			
			ps.setString(1, status);
			ps.setInt(2, appId);
			queryResult = ps.executeUpdate();
			if (queryResult != 0){
			if("Accepted".equals(status)){
				
				ps = con.prepareStatement(IQueryMapper.MODIFY_INTERVIEW_DATE);
				ps.setInt(1, appId);
				 qResult = ps.executeUpdate();
				 if(qResult !=0){
				ps = con.prepareStatement(IQueryMapper.GET_INTERVIEW_DATE);
				ps.setInt(1, appId);
				resultset = ps.executeQuery();
			
			if(resultset.next()){
				String dateOfInterview = resultset.getString(1);
				return dateOfInterview;
			}
				 }
			}else{
				System.out.println("The Loan Application Having Application Id "+appId+" Has Been "+status);
				return null;
			}
			
			}
		}
			catch (SQLException sqlException) {
				throw new LoanException("Exception: "+sqlException.getMessage());
		}
		return null;
	}



	//------------------------ 1. Loan Application Processing System --------------------------
	/*******************************************************************************************************
	 - Function Name	:	getCurrentStatus(int appId)
	 - Input Parameters	:	int appId
	 - Return Type		:	String
	 - Throws			:  	LoanException
	 - Author			:	Shalu Kumari
	 - Creation Date	:	27/08/2018
	 - Description		:	Getting Current Status.
	 ********************************************************************************************************/


	@Override
	public String getCurrentStatus(int appId) {

		String	currentStatus = null;
		try {
			con = DBConnection.establishConnection();
			
			
			ps = con.prepareStatement(IQueryMapper.GET_CUSTOMER_NAME);
			ps.setInt(1, appId);
			resultset = ps.executeQuery();
			if(!resultset.next()){
				ps= con.prepareStatement(IQueryMapper.REJECT_APPLICATION);
				ps.setInt(1, appId);
				resultset = ps.executeQuery();
				if(!resultset.next()){
					System.err.println("This Application id Does Not Exist... Please Enter A Valid Application Id!!");
					return null;
				}else{
				currentStatus = "Rejected";
				return currentStatus;
				}
				}
			else{
			ps=con.prepareStatement(IQueryMapper.GET_APPLICATION_STATUS);
			ps.setInt(1, appId);
			resultset = ps.executeQuery();
			
			if(resultset.next())	{
			 currentStatus = resultset.getString(1);
			return currentStatus;
			}
			}} catch (SQLException sqlException) {
				System.err.println("Error Occured At Getting Current Status ... !!");
			}
		return null;
	}


	//------------------------ 1. Loan Application Processing System --------------------------
	/*******************************************************************************************************
	 - Function Name	:	getCustomerName(int appId)
	 - Input Parameters	:	int appId
	 - Return Type		:	String
	 - Throws			:  	LoanException
	 - Author			:	Shalu Kumari
	 - Creation Date	:	27/08/2018
	 - Description		:	Getting Customer Name.
	 ********************************************************************************************************/



	@Override
	public String getCustomerName(int appId) {
		try {
			con = DBConnection.establishConnection();
			ps = con.prepareStatement(IQueryMapper.GET_CUSTOMER_NAME);
			ps.setInt(1, appId);
			resultset = ps.executeQuery();
			if(resultset.next())
			{
				String customerName = resultset.getString(1);
				return customerName;
			}
		} catch (SQLException sqlException) {
			System.err.println("Error Occured At Getting Customer Name ...!!!");
		}
		return null;
	}


	//------------------------ 1. Loan Application Processing System --------------------------
	/*******************************************************************************************************
	 - Function Name	:	getAmountOfLoanGranted(int appId)
	 - Input Parameters	:	int appId
	 - Return Type		:	long
	 - Throws			:  	LoanException
	 - Author			:	Shalu Kumari
	 - Creation Date	:	27/08/2018
	 - Description		:	Getting Amount Of Loan That Has Been Granted.
	 ********************************************************************************************************/



	@Override
	public long getAmountOfLoanGranted(int appId) {
		try {
			con = DBConnection.establishConnection();
			ps = con.prepareStatement(IQueryMapper.GET_AMOUNT_OF_LOAN_GRANTED);
			ps.setInt(1, appId);
			resultset = ps.executeQuery();
			if(resultset.next()){
				long amountOfLoanGranted = resultset.getLong(1);
				return amountOfLoanGranted;
			}
		} catch (SQLException sqlException) {
			System.err.println("Error Occured At Getting Amount Of Loan Granted..!!");
		}
		return 0;
	}


	//------------------------ 1. Loan Application Processing System --------------------------
	/*******************************************************************************************************
	 - Function Name	:	getYearsTimePeriod(int appId)
	 - Input Parameters	:	int appId
	 - Return Type		:	int
	 - Throws			:  	LoanException
	 - Author			:	Shalu Kumari
	 - Creation Date	:	27/08/2018
	 - Description		:	Getting Years Time Period.
	 ********************************************************************************************************/



	@Override
	public int getYearsTimePeriod(int appId) {
		try {
			con = DBConnection.establishConnection();
			ps = con.prepareStatement(IQueryMapper.GET_YEARS_TIME_PERIOD);
			ps.setInt(1, appId);
			resultset = ps.executeQuery();
			if(resultset .next()){
				int yearsTimePeriod = resultset.getInt(1);
				return yearsTimePeriod;
				
			}
		} catch (SQLException sqlException) {
			System.err.println("Error Occured at Getting Years Time Period.. !!");
		}
		return 0;
	}


	//------------------------ 1. Loan Application Processing System --------------------------
	/*******************************************************************************************************
	 - Function Name	:	getRateOfInterest(int appId)
	 - Input Parameters	:	int appId
	 - Return Type		:	float
	 - Throws			:  	LoanException
	 - Author			:	Shalu Kumari
	 - Creation Date	:	27/08/2018
	 - Description		:	Getting Rate Of Interest.
	 ********************************************************************************************************/



	@Override
	public float getRateOfInterest(int appId) {
		try {
			con = DBConnection.establishConnection();
			ps = con.prepareStatement(IQueryMapper.GET_RATE_OF_INTEREST);
			ps.setInt(1, appId);
			resultset = ps.executeQuery();
			if(resultset.next()){
				float rateOfInterest = resultset.getFloat(1);
				return rateOfInterest;
			}
		} catch (SQLException sqlException) {
			System.err.println("Error At Getting The Rate Of Interest... !!");
		}
		return 0;
	}


	//------------------------ 1. Loan Application Processing System --------------------------
	/*******************************************************************************************************
	 - Function Name	:	addApprovedLoansDetails(ApprovedLoansBean approvedLoansBean)
	 - Input Parameters	:	ApprovedLoansBean approvedLoansBean
	 - Return Type		:	boolean
	 - Throws			:  	LoanException
	 - Author			:	Shalu Kumari
	 - Creation Date	:	27/08/2018
	 - Description		:	Adding Approved Loans To The ApprovedLoans Table.
	 ********************************************************************************************************/



	@Override
	public boolean addApprovedLoansDetails(ApprovedLoansBean approvedLoansBean) {
		int queryResult = 0;
		try {
			con = DBConnection.establishConnection();
			ps = con.prepareStatement(IQueryMapper.ADD_APPROVED_LOANS);
			
			ps.setString(1, approvedLoansBean.getCustomerName());
			ps.setLong(2, approvedLoansBean.getAmountOfLoanGranted());
			ps.setDouble(3, approvedLoansBean.getMonthlyInstallment());
			ps.setInt(4, approvedLoansBean.getYearsTimePeriod());
			ps.setDouble(5, approvedLoansBean.getDownpayment());
			ps.setFloat(6, approvedLoansBean.getRateOfInterest());
			ps.setDouble(7, approvedLoansBean.getTotalAmountPayable());
			
			queryResult = ps.executeUpdate();
			if(queryResult !=0)
				return true;
			else
				return false;
		} catch (SQLException sqlException) {
			System.err.println("Error Occured At Adding Approved Loans Details .. !!");
		}
		return false;
	}






	

}
