package com.capgemini.laps.dao;

import java.util.List;


import com.capgemini.laps.bean.LoanProgramsBean;
import com.capgemini.laps.exception.LoanException;

public interface ILoanProgramsDAO {

	public abstract List<LoanProgramsBean> displayAll() throws LoanException;

	public abstract String login(String logid, String pwd) throws LoanException;

	
	

	
}
