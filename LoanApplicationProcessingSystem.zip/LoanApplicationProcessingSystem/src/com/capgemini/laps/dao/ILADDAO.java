package com.capgemini.laps.dao;

import java.util.List;

import com.capgemini.laps.bean.ApprovedLoansBean;
import com.capgemini.laps.bean.LoanApplicationBean;
import com.capgemini.laps.exception.LoanException;

public interface ILADDAO {

	

	public abstract List<LoanApplicationBean> viewApplications(String loanProgram) throws LoanException;

	public abstract String modifyApplicationStatus(int appId, String status) throws LoanException;

	public abstract String getCurrentStatus(int appId);

	public abstract String getCustomerName(int appId);

	public abstract long getAmountOfLoanGranted(int appId);

	public abstract int getYearsTimePeriod(int appId);

	public abstract float getRateOfInterest(int appId);

	public abstract boolean addApprovedLoansDetails(ApprovedLoansBean approvedLoansBean);

}
