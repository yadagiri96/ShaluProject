package com.capgemini.laps.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;










import com.capgemini.laps.bean.LoanProgramsBean;
import com.capgemini.laps.dbutil.DBConnection;
import com.capgemini.laps.exception.LoanException;

public class LoanProgramsDAO implements ILoanProgramsDAO {

	Connection con=null;
	PreparedStatement ps=null;
	ResultSet resultset = null;
	
	//------------------------ 1. Loan Application Processing System --------------------------
		/*******************************************************************************************************
		 - Function Name	:	displayAll()
		 - Input Parameters	:	no parameters
		 - Return Type		:	List<LoanProgramsBean>
		 - Throws			:  	LoanException
		 - Author			:	Shalu Kumari
		 - Creation Date	:	27/08/2018
		 - Description		:	Displaying all the available loan programs.
		 ********************************************************************************************************/
	
	@Override
	public List<LoanProgramsBean> displayAll() throws LoanException{
		
		int loanProgramsCount = 0;
		
		
		    try {
			con=DBConnection.establishConnection();
		
		
		
		
		List<LoanProgramsBean> loanProgramsList=new LinkedList<LoanProgramsBean>();
		
			ps=con.prepareStatement(IQueryMapper.RETRIVE_ALL_QUERY);
			resultset=ps.executeQuery();
			
			while(resultset.next())
			{	
				LoanProgramsBean bean=new LoanProgramsBean();
				bean.setProgramName(resultset.getString(1));
				bean.setDescription(resultset.getString(2));
				bean.setType(resultset.getString(3));
				bean.setDurationInYears(resultset.getInt(4));
				bean.setMinLoanAmount(resultset.getLong(5));
				bean.setMaxLoanAmount(resultset.getLong(6));
				bean.setRateOfInterest(resultset.getFloat(7));
				bean.setProofsRequired(resultset.getString(8));
				
				loanProgramsList.add(bean);
				
				loanProgramsCount++;
			}			
			
			if( loanProgramsCount == 0)
				return null;
			else
				return loanProgramsList;
		} catch (SQLException sqlException) {
			
			throw new LoanException("Exception: "+sqlException.getMessage());
		}
		
		
	
		
		
	}
	
	
	//------------------------ 1. Loan Application Processing System --------------------------
		/*******************************************************************************************************
		 - Function Name	:	login(String logid, String pwd)
		 - Input Parameters	:	String logid, String pwd
		 - Return Type		:	String
		 - Throws			:  	LoanException
		 - Author			:	Shalu Kumari
		 - Creation Date	:	27/08/2018
		 - Description		:	Login and getting the role .
		 ********************************************************************************************************/
	
	
	@Override
	public String login(String logid, String pwd) throws LoanException {

		String role = null;
		try {
			con=DBConnection.establishConnection();
			ps = con.prepareStatement(IQueryMapper.LOGIN_QUERY);
			ps.setString(1, logid);
			ps.setString(2, pwd);
			resultset=ps.executeQuery();
			
			if(resultset.next()){
				role = resultset.getString(1);
				return role;
			}
			else{
				//System.out.println();
				//System.out.println("======================================");
				System.err.println("Invalid Username or Password ...!! ");
				return null;
			}
		} catch (SQLException sqlException) {
			throw new LoanException("Exception: "+sqlException.getMessage());
		}
		
	}
	
	
	
	
	




	



	
}


