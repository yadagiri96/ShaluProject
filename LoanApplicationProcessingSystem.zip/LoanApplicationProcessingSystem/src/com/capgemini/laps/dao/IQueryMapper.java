package com.capgemini.laps.dao;

public interface IQueryMapper {

	public static final String RETRIVE_ALL_QUERY="select * from LoanProgramsOffered";
	//public static final String LOGIN_QUERY_LAD="select Login_Id,Password from Users where Login_Id = ? and Password = ? and Role='lad'";
	//public static final String LOGIN_QUERY_ADMIN="select Login_Id,Password from Users where Login_Id = ? and Password = ? and Role='admin'";
	public static final String LOGIN_QUERY = "select Role from Users where Login_Id = ? and Password = ?";
	
	
	
	public static final String APPLICATION_ID_QUERY_SEQUENCE="SELECT applicationId_sequence.CURRVAL FROM DUAL";
	public static final String INSERT_QUERY_LOAN_APPLICATION="INSERT INTO LoanApplication VALUES(applicationId_sequence.NEXTVAL,SYSDATE,?,?,?,?,?,?,?,'Applied',SYSDATE +7)";
	public static final String INSERT_QUERY_CUSTOMER_DETAILS="INSERT INTO CustomerDetails VALUES(?,?,?,?,?,?,?,?)";
	public static final String GET_APPLICATION_STATUS="SELECT Status FROM LoanApplication WHERE Application_Id = ?";
	
	
	
	public static final String INSERT_QUERY_LOAN_PROGRAMS = "insert into LoanProgramsOffered values(?,?,?,?,?,?,?,?)";
	public static final String DELETE_LOAN_PROGRAM_QUERY = "delete from LoanProgramsOffered where Program_Name = ?";
	public static final String VIEW_LOAN_APPLICATION_QUERY ="select * from LoanApplication where Status = ? order by Application_Id";
	public static final String RETRIVE_ALL_APPROVED_LOANS="select * from ApprovedLoans";
	
	
	public static final String VIEW_LOAN_APPLICATION_ON_THE_BASIS_OF_LOANPROGRAM ="select * from LoanApplication where Loan_Program = ? order by Application_Id";
	public static final String MODIFY_APPLICATION_STATUS ="UPDATE LoanApplication SET Status = ? where Application_Id =?";
	public static final String MODIFY_INTERVIEW_DATE ="UPDATE LoanApplication SET Date_Of_Interview = SYSDATE + 7 where Application_Id =?";
	public static final String GET_INTERVIEW_DATE ="select Date_Of_Interview from LoanApplication where Application_Id = ?";
    public static final String GET_CUSTOMER_NAME = "select Applicant_Name from CustomerDetails where Application_Id = ?";
    public static final String REJECT_APPLICATION ="UPDATE LoanApplication SET Status = 'Rejected' where Application_Id =?";
    
    
    public static final String GET_AMOUNT_OF_LOAN_GRANTED ="select Amount_Of_Loan from LoanApplication where Application_Id = ? ";
    public static final String GET_YEARS_TIME_PERIOD ="select lp.Duration_In_Years from LoanProgramsOffered lp, LoanApplication la where la.Loan_Program = lp.Program_Name and la.Application_Id = ?";
    public static final String GET_RATE_OF_INTEREST ="select lp.Rate_Of_Interest from LoanProgramsOffered lp, LoanApplication la where la.Loan_Program = lp.Program_Name and la.Application_Id = ?";
    public static final String ADD_APPROVED_LOANS = "insert into ApprovedLoans values(?,?,?,?,?,?,?)";
    

}
