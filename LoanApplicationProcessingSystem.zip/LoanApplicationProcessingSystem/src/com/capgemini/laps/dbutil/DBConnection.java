package com.capgemini.laps.dbutil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

	public static Connection con = null;

	public static Connection establishConnection() throws SQLException {
		con = DriverManager.getConnection(
				"jdbc:oracle:thin:@10.219.34.3:1521:orcl", "trg201",
				"training201");
		return con;
	}

}
